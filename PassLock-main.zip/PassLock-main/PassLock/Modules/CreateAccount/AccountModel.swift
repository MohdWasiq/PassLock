//
//  AccountModel.swift
//  PassLock
//
//  Created by Ahmad Qureshi on 10/08/22.
//

import Foundation
struct AccountModel {
    var name : String
    var email : String
    var password : String
    var confirmPassword : String
}
