//
//  LoginVC.swift
//  PassLock
//
//  Created by Ahmad Qureshi on 01/08/22.
//

import UIKit

class IntroVC: BaseVC {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
