# PassLock
It is an iOS Application that saves the password of the different applications in Keychain at local level

* sets passlock password to verify before opening application again
* users can add any application inside application and enter their respective password 
* this application saves passwords in Keychain of the individual app at local level (at present but can also use APIs to make it global)
* added applications can also be added in favourite sections and also be deleted if users wants


https://user-images.githubusercontent.com/81093987/187189057-198bf82a-204a-401d-8cf0-2cada8d5041b.mp4

